/******************************************************************************
���ϸ�	: InChannelScene.h
����		: inChannel�� ��ü
******************************************************************************/
#pragma once

class InChannelScene : public BaseScene
{
public:
	InChannelScene();
	InChannelScene(UINT id);
	~InChannelScene();

	void Init();
	void Update();
};


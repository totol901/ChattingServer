/******************************************************************************
���ϸ�	: MainClass.h
����		: ChattingClient ��ü, ���� ���� �����
******************************************************************************/
#pragma once

class MainClass
{
private:
	bool isOn;

public:
	MainClass();
	~MainClass();

	HRESULT Init();
	void Release();
	void Update();
	void Render();

	LRESULT CALLBACK MainProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
};

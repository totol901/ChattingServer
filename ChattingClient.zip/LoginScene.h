/******************************************************************************
���ϸ�	: LoginScene.h
����		: �α��ξ� ó��
******************************************************************************/
#pragma once

class LoginScene : public BaseScene
{
private:

public:
	LoginScene();
	LoginScene(UINT id);
	~LoginScene();

	void Init();
	void Update();
};

/******************************************************************************
���ϸ�	: WaittingChannelScene.h
����		: ������ ä�ξ� ��ü
******************************************************************************/
#pragma once

class WaittingChannelScene : public BaseScene
{
public:
	WaittingChannelScene();
	WaittingChannelScene(UINT id);
	~WaittingChannelScene();

	void Init();
	void Update();
};

